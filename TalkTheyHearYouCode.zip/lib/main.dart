import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(TalkTheyHearYouApp());
}

class TalkTheyHearYouApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Talk, They Hear You',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Talk, They Hear You'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset(
                  'assets/RegularLogo.png',
                  height: 100,
                ),
                Image.asset(
                  'assets/image.png',
                  height: 100,
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Time to Talk! Conversation Cards are helpful tools to start meaningful and frequent conversations with the young people in your life.',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Text(
              'Choose a deck and draw a card to begin!',
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DeckSelectionPage(),
                  ),
                );
              },
              child: Text('Select a Deck'),
            ),
          ],
        ),
      ),
    );
  }
}

class DeckSelectionPage extends StatelessWidget {
  final List<String> decks = [
    'For Families',
    'For Schools',
    'For Law Enforcement',
    'For Healthcare',
    'For Military Families',
    'For Coaches',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select a Deck'),
      ),
      body: ListView.builder(
        itemCount: decks.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(decks[index]),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CardGamePage(deckName: decks[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class CardGamePage extends StatefulWidget {
  final String deckName;

  CardGamePage({required this.deckName});

  @override
  _CardGamePageState createState() => _CardGamePageState();
}

class _CardGamePageState extends State<CardGamePage> {
  final Map<String, List<String>> cards = {
    'Blue': [
      'What is an activity you like to do to avoid boredom and alcohol or drug use?',
      'What is the weirdest thing you have eaten?',
      'If you had one wish, what would it be?',
      // Add more questions
    ],
    'Yellow': [
      'What makes you feel loved?',
      'What is one thing that is important to you?',
      // Add more questions
    ],
    'Green': [
      'If you were offered drugs or alcohol, what is something you could do or say to refuse it?',
      'If you could stop doing one chore around the house, what would it be?',
      // Add more questions
    ],
    'Pink': [
      'What was your first job? Did you like it?',
      'What was one thing you did when you were a kid that made you the happiest?',
      // Add more questions
    ],
  };

  String? currentCard;
  String? currentColor;

  void drawCard() {
    final colors = cards.keys.toList();
    final randomColor = colors[Random().nextInt(colors.length)];
    final cardList = cards[randomColor]!;
    final randomCard = cardList[Random().nextInt(cardList.length)];

    setState(() {
      currentColor = randomColor;
      currentCard = randomCard;
    });
  }

  Widget buildStyledCard(String color, String question) {
    Color cardColor;
    switch (color) {
      case 'Blue':
        cardColor = Colors.blue.shade300;
        break;
      case 'Green':
        cardColor = Colors.green.shade300;
        break;
      case 'Pink':
        cardColor = Colors.pink.shade300;
        break;
      case 'Yellow':
        cardColor = Colors.yellow.shade300;
        break;
      default:
        cardColor = Colors.grey;
    }

    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 8,
            offset: Offset(2, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            question,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.deckName} Cards'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (currentCard != null && currentColor != null)
              buildStyledCard(currentColor!, currentCard!),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: drawCard,
              child: Text('Draw Card'),
            ),
          ],
        ),
      ),
    );
  }
}
